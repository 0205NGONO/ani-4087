int FonctionDeB() {
    return 42;
}