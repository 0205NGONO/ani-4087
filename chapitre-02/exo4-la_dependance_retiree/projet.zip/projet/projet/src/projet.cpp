#include <iostream>

extern int FonctionDeA(); // declaree dans BiblioA

int main() {
    std::cout << FonctionDeA() << "\n";
    return 0;
}