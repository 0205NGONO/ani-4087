extern int FonctionDeB(); // declaree ailleurs, dans BiblioB

int FonctionDeA() {
    return FonctionDeB() + 1;
}