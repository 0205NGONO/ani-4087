#include <iostream>

int main() {
#ifdef MODULE_ACTIF
    std::cout << "Definition recue : MODULE_ACTIF est actif\n";
#else
    std::cout << "Definition non recue : MODULE_ACTIF est absent\n";
#endif
    return 0;
}
